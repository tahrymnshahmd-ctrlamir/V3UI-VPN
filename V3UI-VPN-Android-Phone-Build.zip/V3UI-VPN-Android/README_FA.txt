پروژه اندروید V3UI VPN

این پروژه فایل HTML شما را داخل Android WebView نمایش می‌دهد.

ساخت APK:
1) Android Studio را نصب کنید.
2) پوشه V3UI-VPN-Android را از مسیر File > Open باز کنید.
3) صبر کنید Gradle Sync کامل شود.
4) از منوی Build گزینه Build Bundle(s) / APK(s) > Build APK(s) را بزنید.
5) فایل APK از مسیر app/build/outputs/apk/debug/app-debug.apk قابل دریافت است.

نکته مهم:
این نسخه فقط رابط HTML را در اپ اندروید اجرا می‌کند. دکمه اتصال، پینگ، سرعت، حجم مصرفی و وضعیت سرورها در HTML نمایشی هستند.
برای VPN واقعی باید سرورهای واقعی، تنظیمات/اشتراک معتبر و پیاده‌سازی Android VpnService یا هسته VPN مناسب اضافه شود.
برای بارگذاری فونت‌ها و منابع CDN در زمان اجرا، اینترنت لازم است.
